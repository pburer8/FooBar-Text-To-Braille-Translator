import java.util.HashMap;
class Main {
	public static String solution(String s) {
    	String braille = "";
    	
    	HashMap <Character, String> alphabet = new HashMap<>();
    	alphabet.put('a', "100000");
    	alphabet.put('b', "110000");
    	alphabet.put('c', "100100");
    	alphabet.put('d', "100110");
    	alphabet.put('e', "100010");
    	alphabet.put('f', "110100");
    	alphabet.put('g', "110110");
    	alphabet.put('h', "110010");
    	alphabet.put('i', "010100");
    	alphabet.put('j', "010110");
    	alphabet.put('k', "101000");
    	alphabet.put('l', "111000");
    	alphabet.put('m', "101100");
    	alphabet.put('n', "101110");
    	alphabet.put('o', "101010");
    	alphabet.put('p', "111100");
    	alphabet.put('q', "111110");
    	alphabet.put('r', "111010");
    	alphabet.put('s', "011100");
    	alphabet.put('t', "011110");
    	alphabet.put('u', "101001");
    	alphabet.put('v', "111001");
    	alphabet.put('w', "010111");
    	alphabet.put('x', "101101");
    	alphabet.put('y', "101111");
    	alphabet.put('z', "101011");
    	alphabet.put(' ', "000000");
    	
    	for (int i = 0; i<s.length(); i++)
    	{
    	    char j = s.charAt(i);
    	    
    	    if (Character.isUpperCase(j))
    	    {
    	        braille += "000001";
    	    }
    	    
    	    braille+= alphabet.get(Character.toLowerCase(j));
    	}
    	
    	return braille;
    }

  public static void main(String[] args) {
    System.out.println(solution("West High Computer Science"));

  }
}